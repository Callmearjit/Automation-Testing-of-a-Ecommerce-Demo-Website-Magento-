# Luma E-commerce Website Testing

## ✅ Technologies Used
- Java + Selenium WebDriver
- TestNG
- Maven
- Allure Reporting

## 📌 Features Tested
- Login functionality

## 🧱 Folder Structure
- `pages/` – Page Object classes
- `tests/` – Test cases using TestNG
- `utils/` – WebDriver factory
- `docs/` – Test reports/screenshots

## 🚀 Run the Tests
```bash
mvn clean test
allure serve target/allure-results
```

## 📄 Resume Line
> Tested critical modules of an E-commerce website using manual and automated techniques with Selenium WebDriver and TestNG.
