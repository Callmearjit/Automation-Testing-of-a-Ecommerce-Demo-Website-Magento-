package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import utils.WebDriverFactory;

public class LoginTest {
    private WebDriver driver;

    @BeforeMethod
    public void setup() {
        driver = WebDriverFactory.createWebDriver();
        driver.get("https://magento.softwaretestingboard.com/customer/account/login/");
    }

    @Test(description = "Verify login with valid credentials")
    public void testValidLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.performLogin("user@example.com", "Password123");
        Assert.assertTrue(driver.getTitle().contains("My Account"));
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}